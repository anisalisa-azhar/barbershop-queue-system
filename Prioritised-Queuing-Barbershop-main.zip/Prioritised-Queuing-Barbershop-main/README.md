# In order to start the Frontend perfom in terminal:
1- cd Frontend
2- npm install

# To run the frontend 
npm start


The installation must be done individually in every collaborator otherwise its not going to work