import barberSign from "./barbersign.jpg";
import boxingHarcut from "./boxingHaircut.jpg";
import BeardTrimming from "./BeardTrimming.jpg";
import Store from "./Store.jpg";
import LowFade from "./LowFade.jpg";
import ShakeHands from "./ShakeHands.jpg";
import Chairs from "./Chairs.jpg";
import fade from "./fade.jpg";
import manBun from "./man bun.png";
import pompadour from "./pompadour.jpg";
import undercut from "./undercut.jpg";
import buzzCut from "./buzz cut.jpg";
import basicHaircut from "./basicHaircut.jpg";
import haircutBeardTrim from "./BeardTrimming.jpg";
import deluxeGroom from "./deluxeGroom.jpeg";

export {
    barberSign,
    boxingHarcut,
    BeardTrimming,
    Store,
    LowFade,
    ShakeHands,
    Chairs,
    fade, 
    manBun, 
    pompadour, 
    undercut, 
    buzzCut,
    basicHaircut, 
    haircutBeardTrim, 
    deluxeGroom
}