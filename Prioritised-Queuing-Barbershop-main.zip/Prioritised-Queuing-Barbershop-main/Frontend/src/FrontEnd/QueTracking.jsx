
const QueTracking = () => {
  return (
    <div>
      
    </div>
  )
}

export default QueTracking
