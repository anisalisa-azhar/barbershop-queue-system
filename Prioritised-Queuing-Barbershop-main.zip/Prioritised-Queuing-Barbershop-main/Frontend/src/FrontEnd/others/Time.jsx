import React from 'react'

export const Time = () => {
  return (
    <div>Time</div>
  )
}
