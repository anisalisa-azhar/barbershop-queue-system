

const Header = () => {
  return (
    <div className=' mt-2 mb-6 bg-black'>
        <nav>
            <a href='/'>
                <p cla>Home</p>
            </a>
            <a href='/que'>
                <li>Que</li>
            </a>
        </nav>
    </div>
  )
}

export default Header;
